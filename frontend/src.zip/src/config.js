// config.js
export const BASE_URL = 'http://localhost:8000';
